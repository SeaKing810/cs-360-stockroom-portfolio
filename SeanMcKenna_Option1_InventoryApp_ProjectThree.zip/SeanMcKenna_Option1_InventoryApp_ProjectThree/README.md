# Stockroom

Sean McKenna · CS 360 Project Three · Option 1 Inventory App

Stockroom is a Java/XML Android inventory application built from the Project Two interface. It supports local account registration and login, account-specific SQLite inventory, persistent create/read/update/delete operations, an adaptive grid, and optional zero-stock SMS alerts. A new installation contains no accounts or inventory fixtures.

## Open and run

1. Extract the project ZIP and open the enclosed `SeanMcKenna_Option1_InventoryApp_ProjectThree` folder in Android Studio.
2. Use Android Studio Quail 4 / 2026.1.4 or a compatible newer version, JDK 25, and Android SDK Platform 37. The project includes Gradle 9.6.0 and Android Gradle Plugin 9.4.0. Allow dependency synchronization and SDK installation if prompted.
3. Run the app on Android 9 / API 28 or newer. The compile and target SDK are 37 (Android 17).
4. Choose **Create account**, enter a unique username (3–32 letters, numbers, dots, underscores, or hyphens), and a password of 8–128 characters. Confirm the password and submit. Password hashing runs in the background; allow a few seconds on slower emulators.
5. Choose **Add item**, supply the name, unique SKU, optional location, and a quantity from 0 to 1,000,000. Save. Use Edit, Delete, or the quantity controls on its card. Scroll to see all card controls on smaller screens.
6. Search by name or SKU, or select **Zero stock**. Log out through the toolbar overflow menu. Accounts and records remain in SQLite; a fresh launch requires login. Rotation preserves the active screen/session.

The database is private to this installation. Accounts do not sync between devices. Clearing app storage or uninstalling removes all local data. There is no remote account recovery.

## SMS walkthrough

1. Open **SMS alerts** using the message icon. Merely opening this screen does not prompt for permission.
2. Select **Enable SMS access** and choose Allow or Deny in Android's permission dialog. After a denial, all inventory operations remain available. When Android prevents another prompt, the app offers **Open app settings**.
3. To enable delivery, grant permission, enter a country-code recipient such as `+15551234567`, turn on **Zero-stock SMS alerts**, and select **Save alert preferences**. Use only a recipient who has agreed to receive the alerts. Carrier charges may apply.
4. Add an item with quantity 1, then reduce it to zero. Editing a positive quantity to zero also triggers an alert. Creating an already-zero item, editing zero to zero, viewing inventory, and deleting a record do not trigger texts. Restock an item and drop it to zero again to create another event.
5. Return to SMS alerts to see the latest send result. A grant alone does not turn on sending. Each attempt also checks the account preference, recipient, hardware, current permission, and default SMS subscription.

A functioning SIM and SMS service are required on a physical device. On a dual-SIM device, choose a default SMS SIM in Android settings. Failed or unavailable SMS delivery does not undo a saved inventory change. “Sent to SMS service” means modem acceptance, not confirmed recipient delivery. No automatic retry is performed, avoiding unexpected duplicate texts. If the process stops between database commit and modem submission, the event remains pending; reopening does not resend it.

For an emulator-only trial, use the emulator's virtual phone number; this does not establish carrier delivery. See `docs/TEST_RESULTS.md` for the precise tests performed and limitations. Do not use the emulator to send to a real person's number.

## Design and implementation

- `StockroomDatabase`: SQLiteOpenHelper, schema creation, validated CRUD, bound query arguments, per-account ownership, unique usernames/SKUs, database transactions, and persistent SMS settings/events.
- `PasswordHasher`: PBKDF2-HMAC-SHA256 with 600,000 iterations, a random 16-byte salt, a 256-bit hash, and constant-time hash comparison. Passwords are never written to SQLite or saved view state.
- `StockroomApp` and `MainActivity`: a serial background executor, lifecycle-checked UI callbacks, account/session state, and screen navigation.
- `LoginFragment`, `InventoryFragment`, `ItemFormFragment`: account creation/authentication, RecyclerView/GridLayoutManager, search and filtering, confirmed deletion, and validated forms. One column is used on phones; two columns are used when space and text scale allow.
- `NotificationSettingsFragment`, `SmsNotifier`, `SmsSentReceiver`: contextual permission requests, optional preferences, permission rechecks immediately before sending, and asynchronous modem status recording.

The Project Two design was reviewed before connecting functionality. Preview-only labels and fixture records were replaced with saved data, an empty state, input errors, login progress, saveable alert preferences, and an actual SMS status. No additional instructor feedback was supplied.

## Build and tests

```sh
./gradlew :app:assembleDebug :app:lintDebug :app:testDebugUnitTest
```

On Windows, use `gradlew.bat`. JDK 25 is required. The project ZIP excludes generated builds, IDE session files, local SDK paths, Gradle caches, test account databases, and signing keys. The separate APK is a debug-signed installable build for course review, not a store release.

There are 20 automated tests covering account validation, password hashing, persistent CRUD, account isolation, unique SKUs, quantity limits, zero-stock transitions, SMS grant/denial/opt-out/missing hardware/missing SIM, UI login, item entry, search, rotation, logout, and tablet grid columns. See `docs/TEST_RESULTS.md` for results.

## Store launch boundary

The launch plan is supplied separately as a Word document. Google Play restricts `SEND_SMS`; ordinary runtime consent does not guarantee eligibility. Before public distribution, assess the current permission policy and obtain an applicable approval or remove the permission and automatic texting from the public variant. The course build implements the rubric's direct SMS requirement. No app-store publication has been performed.

References: [Android 17](https://developer.android.com/about/versions/17), [runtime permissions](https://developer.android.com/training/permissions/requesting), [SmsManager](https://developer.android.com/reference/android/telephony/SmsManager), [Google Play SMS policy](https://support.google.com/googleplay/android-developer/answer/10208820?hl=en).
