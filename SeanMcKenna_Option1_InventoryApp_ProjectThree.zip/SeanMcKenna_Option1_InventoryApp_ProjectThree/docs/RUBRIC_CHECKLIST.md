# Project Three requirement mapping

| Requirement | Implementation and evidence |
| --- | --- |
| Verify username and password against database | `LoginFragment` calls `StockroomDatabase.authenticate`; salted hashes are verified by `PasswordHasher`. Invalid credentials leave the user on login. |
| Create and save a new account | `StockroomDatabase.register` inserts a unique username, salt, and password hash into `users`. No preloaded account is required. |
| Persistent SQLite database shell | `StockroomDatabase.onCreate` creates `users`, `inventory`, and `sms_events` without sample rows. Preferences and phone numbers live in `users`. |
| Create | Item form validates fields, then inserts into `inventory`. |
| Read in a grid | `InventoryFragment` reads account-owned rows and binds them to RecyclerView with GridLayoutManager. Search and zero-stock filtering use those records. |
| Update | Edit changes all item fields; plus/minus controls update the stored quantity. |
| Delete | Per-card and edit-screen delete controls request confirmation and remove the selected account-owned row. |
| Persist after closing | SQLite stores all users, items, phone numbers, preferences, and alert statuses. Emulator restart and database reopen tests verify persistence. |
| Request SMS permission | Optional `SEND_SMS` manifest permission and contextual Android runtime request in `NotificationSettingsFragment`. |
| Granted permission | After a valid phone number and explicit saved opt-in, a positive-to-zero transition calls `SmsManager.sendTextMessage`. A private callback receiver records the modem result. |
| Denied permission | Permission is checked at send time. Denial/revocation skips SMS; accounts and CRUD continue working. |
| App-specific trigger | An existing inventory item's quantity changes from a positive value to exactly zero. Transactional event creation prevents a zero-to-zero edit from creating a new alert. |
| Readability | Java classes separate persistence, hashing, sending, and UI. Descriptive identifiers and comments explain security, transactions, lifecycle boundaries, and alert behavior. |
| Launch plan | Separate three-page Word document covers audience, store description/icon, Android support, permissions/Play policy, pricing, release testing, distribution, and support. |

## Database structure

- `users`: `_id`, case-insensitive unique `username`, `password_hash`, `salt`, `phone`, `sms_enabled`.
- `inventory`: `_id`, `user_id` foreign key, `name`, case-insensitive `sku`, `location`, `quantity`; unique `(user_id, sku)` and a checked quantity range.
- `sms_events`: `_id`, `user_id` foreign key, `sku`, `status`, `created_at`; records zero crossings and the resulting SMS status.

All inventory reads and mutations include the authenticated user ID. SQLite foreign keys are enabled. Database schema version 1 needs no upgrade migration; future versions must define migrations without dropping user data.
