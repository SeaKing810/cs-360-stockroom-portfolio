# Stockroom Project Three verification

Test date: September 22, 2026.

## Build and automated checks

- Debug APK build: passed.
- Android Lint: 0 errors, 14 nonblocking warnings. These concern available dependency/Gradle updates, legacy backup configuration, full adapter refresh, background overdraw, and three untranslated login messages. No API compatibility error remains.
- Automated tests: **20 passed, 0 failed, 0 skipped**, using Robolectric on API 34.
- Freshly extracted project ZIP: `assembleDebug` passed without the author's `local.properties` file. The SDK location was supplied through `ANDROID_HOME`.

| Suite | Tests | Verified behavior |
| --- | ---: | --- |
| DatabaseTest | 9 | Empty initial inventory; valid and invalid authentication; case-insensitive usernames; rejected duplicate/invalid accounts; independent salts/hashes; persistent create/read/update/delete; account isolation; SKU/quantity validation; transition-only alerts; stored SMS settings. |
| SmsNotifierTest | 6 | Expected SMS body and destination after grant/opt-in; denial skips SMS while CRUD works; opt-out; missing telephony; missing default SIM; no send without a zero transition. |
| ScreenFlowTest | 5 | Invalid and valid UI login; saved item and search results; rotation and logout; usable inventory navigation without SMS permission; two-column tablet grid. |

The SMS unit tests inspect Robolectric's simulated SMS API calls. They do not contact a carrier.

## Android Emulator

Environment: Android Emulator 37.1.11, Android 11 / API 30 ARM64, 720 × 1280 display. The emulator tests use a temporary local account and a demonstration inventory item. The submitted source and APK contain no populated database or test credentials.

Verified directly in the running app:

1. Create a previously nonexistent account; the initial grid is empty.
2. Add Packing tape, SKU PKG-104, location A1, quantity 2.
3. Edit the name to Shipping tape and the quantity to 1; SQLite contains the changed values.
4. Force-stop and relaunch. An incorrect password is rejected. The correct password opens the previously saved inventory.
5. Request SMS permission through the app, choose Deny, and return to inventory. Decrementing 1 to 0 persists the quantity and records that SMS was not sent.

6. Request permission again through the rationale/dialog, choose Allow, save the emulator-only recipient +15555215554, enable alerts, and save. SQLite confirms the saved phone number and preference.
7. Restock from 0 to 1 and decrement to 0. The real Android SMS API and callback record: **Sent to SMS service (delivery unconfirmed)**. This verifies the emulator send path and callback, not physical carrier delivery.

8. Delete the item through its confirmation dialog. The empty grid appears and SQLite contains zero inventory rows.

9. Reinstall the final APK, clear only the test application data, and launch it again. The login screen opens correctly. The emulator crash buffer contains no Stockroom crash entries.

Screenshots from these actual emulator runs are included in docs/screenshots. They are not mockups.

## Repeat the main checks

1. Install the APK or run the source project. Create a new account.
2. Add an item with quantity 2, edit it to 1, restart the app, and log back in. Confirm the item remains.
3. Enter SMS alerts, request permission, and deny it. Return to inventory and decrement the item to zero. Confirm the quantity changes and the latest alert is marked not sent.
4. Request permission again, allow it, save a valid consenting recipient and an enabled alert preference, restock to 1, then decrement to zero. Check the latest SMS status.
5. Delete the item, confirm the dialog, and verify the empty grid. Create another account to verify that it has separate inventory.

## Practical limits

- Physical-device carrier delivery, the entire Android 9–17 device matrix, and store approval are separate prelaunch checks; they are not established by a debug APK or emulator test.
- No background queue retries an interrupted/failed SMS. Event status persists, and inventory saves are independent of SMS success.
- Data survives app closure, not uninstalling or clearing app storage. Accounts and inventory are local to a device.
- This is a course review build. Public release requires signing/release packaging and the SMS policy decision described in the launch plan.
