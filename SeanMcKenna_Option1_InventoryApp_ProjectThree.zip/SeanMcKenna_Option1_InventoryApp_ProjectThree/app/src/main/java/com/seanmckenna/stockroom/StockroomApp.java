package com.seanmckenna.stockroom;

import android.app.Application;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Serializes database work and password hashing away from the UI thread. */
public class StockroomApp extends Application {
    final ExecutorService worker = Executors.newSingleThreadExecutor();
    StockroomDatabase database;
    @Override public void onCreate() { super.onCreate(); database = new StockroomDatabase(this); }
}
