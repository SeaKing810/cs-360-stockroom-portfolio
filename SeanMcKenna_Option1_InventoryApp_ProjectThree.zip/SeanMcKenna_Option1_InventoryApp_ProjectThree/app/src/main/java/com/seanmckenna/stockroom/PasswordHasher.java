package com.seanmckenna.stockroom;

import java.security.GeneralSecurityException;
import java.security.MessageDigest;
import java.security.SecureRandom;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

/** Salted, deliberately expensive password derivation; never stores plaintext. */
final class PasswordHasher {
    static final int ITERATIONS = 600_000;
    private PasswordHasher() { }
    static byte[] salt() {
        byte[] salt = new byte[16];
        new SecureRandom().nextBytes(salt);
        return salt;
    }
    static byte[] hash(char[] password, byte[] salt) {
        PBEKeySpec spec = new PBEKeySpec(password, salt, ITERATIONS, 256);
        try {
            return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded();
        } catch (GeneralSecurityException e) {
            throw new IllegalStateException("Password protection unavailable.", e);
        } finally {
            spec.clearPassword();
        }
    }
    static boolean matches(char[] password, byte[] salt, byte[] expected) {
        return MessageDigest.isEqual(hash(password, salt), expected);
    }
}
