package com.seanmckenna.stockroom;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Records modem acceptance separately from recipient delivery, which is not guaranteed. */
public class SmsSentReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        long event = intent.getLongExtra("event", -1);
        if (event < 0) return;
        int result = getResultCode();
        PendingResult pending = goAsync();
        StockroomApp app = (StockroomApp) context.getApplicationContext();
        app.worker.execute(() -> {
            try {
                app.database.eventStatus(event, result == Activity.RESULT_OK
                        ? "Sent to SMS service (delivery unconfirmed)"
                        : "SMS failed (code " + result + ") — check SIM and service");
            } finally { pending.finish(); }
        });
    }
}
