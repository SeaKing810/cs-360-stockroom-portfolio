package com.seanmckenna.stockroom;

import android.Manifest;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.telephony.SmsManager;
import android.telephony.SubscriptionManager;
import androidx.core.content.ContextCompat;

/** Sends only a committed positive-to-zero transition; permission is checked at send time. */
final class SmsNotifier {
    private SmsNotifier() { }
    static boolean validPhone(String phone) { return phone.matches("\\+[1-9][0-9]{7,14}"); }
    static boolean permitted(Context context) {
        return ContextCompat.checkSelfPermission(context, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED;
    }
    static boolean supported(Context context) {
        return context.getPackageManager().hasSystemFeature(Build.VERSION.SDK_INT >= 33
                ? PackageManager.FEATURE_TELEPHONY_MESSAGING : PackageManager.FEATURE_TELEPHONY);
    }
    @SuppressWarnings("deprecation")
    static void send(Context context, StockroomDatabase db, long user, long event) {
        if (event < 0) return;
        StockroomDatabase.SmsSettings settings = db.settings(user);
        if (!supported(context) || !permitted(context) || !settings.enabled || !validPhone(settings.phone)) {
            db.eventStatus(event, "Not sent — SMS disabled or unavailable");
            return;
        }
        try {
            int subscription = SubscriptionManager.getDefaultSmsSubscriptionId();
            if (subscription < 0 || subscription == Integer.MAX_VALUE) {
                db.eventStatus(event, "Not sent — select a default SMS SIM in device settings");
                return;
            }
            SmsManager manager = Build.VERSION.SDK_INT >= 31
                    ? context.getSystemService(SmsManager.class).createForSubscriptionId(subscription)
                    : SmsManager.getSmsManagerForSubscriptionId(subscription);
            // ASCII-only SKU and a bounded length keep the alert within one SMS segment.
            String body = "Stockroom: " + db.eventSku(user, event) + " is out of stock. Quantity: 0.";
            Intent result = new Intent(context, SmsSentReceiver.class)
                    .setData(Uri.parse("stockroom://sms/" + event)).putExtra("event", event);
            PendingIntent sent = PendingIntent.getBroadcast(context, 0, result,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            db.eventStatus(event, "Submitted — awaiting SMS service result");
            manager.sendTextMessage(settings.phone, null, body, sent, null);
        } catch (SecurityException | IllegalArgumentException | UnsupportedOperationException e) {
            db.eventStatus(event, "Not sent — check SMS permission, SIM, and service");
        }
    }
}
