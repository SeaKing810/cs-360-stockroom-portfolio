package com.seanmckenna.stockroom;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteConstraintException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** All queries bind user input and scope inventory/settings to the authenticated account. */
final class StockroomDatabase extends SQLiteOpenHelper {
    static final int MAX_QUANTITY = 1_000_000;
    StockroomDatabase(Context context) { super(context, "stockroom.db", null, 1); }
    @Override public void onConfigure(SQLiteDatabase db) { db.setForeignKeyConstraintsEnabled(true); }
    @Override public void onCreate(SQLiteDatabase db) {
        // Start with an empty shell: no sample users, passwords, or inventory.
        db.execSQL("CREATE TABLE users (_id INTEGER PRIMARY KEY, username TEXT NOT NULL UNIQUE COLLATE NOCASE, "
                + "password_hash BLOB NOT NULL, salt BLOB NOT NULL, phone TEXT NOT NULL DEFAULT '', "
                + "sms_enabled INTEGER NOT NULL DEFAULT 0 CHECK(sms_enabled IN (0,1)))");
        db.execSQL("CREATE TABLE inventory (_id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(_id) ON DELETE CASCADE, "
                + "name TEXT NOT NULL, sku TEXT NOT NULL COLLATE NOCASE, location TEXT NOT NULL, "
                + "quantity INTEGER NOT NULL CHECK(quantity BETWEEN 0 AND 1000000), UNIQUE(user_id,sku))");
        db.execSQL("CREATE TABLE sms_events (_id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL REFERENCES users(_id) ON DELETE CASCADE, "
                + "sku TEXT NOT NULL, status TEXT NOT NULL, created_at INTEGER NOT NULL)");
        db.execSQL("CREATE INDEX sms_by_user ON sms_events(user_id, _id)");
    }
    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Future versions must add explicit migrations, never drop the user's inventory.
        throw new IllegalStateException("No migration defined for this database version.");
    }
    long register(String username, char[] password) {
        String normalized = username.trim().toLowerCase(Locale.ROOT);
        if (!normalized.matches("[a-z0-9._-]{3,32}"))
            throw new IllegalArgumentException("Use 3–32 letters, numbers, dots, underscores, or hyphens for the username.");
        if (password.length < 8 || password.length > 128)
            throw new IllegalArgumentException("Use a password with 8–128 characters.");
        byte[] salt = PasswordHasher.salt();
        ContentValues values = new ContentValues();
        values.put("username", normalized);
        values.put("salt", salt);
        values.put("password_hash", PasswordHasher.hash(password, salt));
        try { return getWritableDatabase().insertOrThrow("users", null, values); }
        catch (SQLiteConstraintException e) { throw new IllegalArgumentException("That username already exists. Log in or choose another."); }
    }
    long authenticate(String username, char[] password) {
        try (Cursor cursor = getReadableDatabase().query("users", new String[]{"_id", "salt", "password_hash"},
                "username = ?", new String[]{username.trim()}, null, null, null)) {
            if (cursor.moveToFirst() && PasswordHasher.matches(password, cursor.getBlob(1), cursor.getBlob(2)))
                return cursor.getLong(0);
            return -1;
        }
    }
    List<InventoryItem> items(long user) {
        List<InventoryItem> items = new ArrayList<>();
        try (Cursor cursor = getReadableDatabase().query("inventory", null, "user_id = ?",
                new String[]{String.valueOf(user)}, null, null, "name COLLATE NOCASE, _id")) {
            while (cursor.moveToNext()) items.add(readItem(cursor));
        }
        return items;
    }
    InventoryItem item(long user, long id) {
        try (Cursor cursor = getReadableDatabase().query("inventory", null, "user_id = ? AND _id = ?",
                keys(user, id), null, null, null)) {
            if (!cursor.moveToFirst()) throw new IllegalArgumentException("Item no longer exists. Return to inventory.");
            return readItem(cursor);
        }
    }
    private InventoryItem readItem(Cursor c) {
        return new InventoryItem(c.getLong(c.getColumnIndexOrThrow("_id")),
                c.getString(c.getColumnIndexOrThrow("name")), c.getString(c.getColumnIndexOrThrow("sku")),
                c.getString(c.getColumnIndexOrThrow("location")), c.getInt(c.getColumnIndexOrThrow("quantity")));
    }
    static void validateItem(String name, String sku, String location, int quantity) {
        if (name.trim().isEmpty() || name.trim().length() > 80)
            throw new IllegalArgumentException("Enter an item name with 1–80 characters.");
        if (!sku.trim().matches("[A-Za-z0-9._-]{1,32}"))
            throw new IllegalArgumentException("SKU must use 1–32 letters, numbers, dots, underscores, or hyphens.");
        if (location.trim().length() > 80) throw new IllegalArgumentException("Location must be 80 characters or fewer.");
        if (quantity < 0 || quantity > MAX_QUANTITY)
            throw new IllegalArgumentException("Quantity must be a whole number from 0 to 1,000,000.");
    }
    // Persist the stock change and its zero-crossing event together. Sending happens after commit.
    long saveItem(long user, long id, String name, String sku, String location, int quantity) {
        validateItem(name, sku, location, quantity);
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            InventoryItem previous = id < 0 ? null : item(user, id);
            ContentValues values = new ContentValues();
            values.put("user_id", user); values.put("name", name.trim());
            values.put("sku", sku.trim().toUpperCase(Locale.ROOT));
            values.put("location", location.trim()); values.put("quantity", quantity);
            if (id < 0) db.insertOrThrow("inventory", null, values);
            else db.update("inventory", values, "user_id = ? AND _id = ?", keys(user, id));
            long event = -1;
            if (previous != null && previous.quantity > 0 && quantity == 0) {
                ContentValues alert = new ContentValues();
                alert.put("user_id", user); alert.put("sku", sku.trim().toUpperCase(Locale.ROOT));
                alert.put("status", "Pending send"); alert.put("created_at", System.currentTimeMillis());
                event = db.insertOrThrow("sms_events", null, alert);
            }
            db.setTransactionSuccessful();
            return event;
        } catch (SQLiteConstraintException e) {
            throw new IllegalArgumentException("That SKU already exists in your inventory.");
        } finally { db.endTransaction(); }
    }
    long adjustQuantity(long user, long id, int delta) {
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            InventoryItem current = item(user, id);
            long event = saveItem(user, id, current.name, current.sku, current.location, current.quantity + delta);
            db.setTransactionSuccessful();
            return event;
        } finally { db.endTransaction(); }
    }
    void deleteItem(long user, long id) {
        if (getWritableDatabase().delete("inventory", "user_id = ? AND _id = ?", keys(user, id)) != 1)
            throw new IllegalArgumentException("Item no longer exists.");
    }
    SmsSettings settings(long user) {
        try (Cursor cursor = getReadableDatabase().query("users", new String[]{"phone", "sms_enabled"},
                "_id = ?", new String[]{String.valueOf(user)}, null, null, null)) {
            if (!cursor.moveToFirst()) throw new IllegalArgumentException("Please log in again.");
            return new SmsSettings(cursor.getString(0), cursor.getInt(1) == 1);
        }
    }
    void saveSettings(long user, String phone, boolean enabled) {
        if ((!phone.isEmpty() || enabled) && !SmsNotifier.validPhone(phone))
            throw new IllegalArgumentException("Enter a country code and number, such as +15551234567.");
        ContentValues values = new ContentValues(); values.put("phone", phone); values.put("sms_enabled", enabled ? 1 : 0);
        getWritableDatabase().update("users", values, "_id = ?", new String[]{String.valueOf(user)});
    }
    void disableSms(long user) {
        ContentValues values = new ContentValues(); values.put("sms_enabled", 0);
        getWritableDatabase().update("users", values, "_id = ?", new String[]{String.valueOf(user)});
    }
    String eventSku(long user, long event) {
        try (Cursor c = getReadableDatabase().query("sms_events", new String[]{"sku"}, "user_id = ? AND _id = ?", keys(user, event), null, null, null)) {
            if (!c.moveToFirst()) throw new IllegalArgumentException("Alert no longer exists.");
            return c.getString(0);
        }
    }
    void eventStatus(long event, String status) {
        ContentValues values = new ContentValues(); values.put("status", status);
        getWritableDatabase().update("sms_events", values, "_id = ?", new String[]{String.valueOf(event)});
    }
    String lastAlert(long user) {
        try (Cursor c = getReadableDatabase().query("sms_events", new String[]{"sku", "status"}, "user_id = ?",
                new String[]{String.valueOf(user)}, null, null, "_id DESC", "1")) {
            return c.moveToFirst() ? c.getString(0) + ": " + c.getString(1) : "No zero-stock alerts yet.";
        }
    }
    private String[] keys(long user, long id) { return new String[]{String.valueOf(user), String.valueOf(id)}; }
    static final class SmsSettings {
        final String phone;
        final boolean enabled;
        SmsSettings(String phone, boolean enabled) { this.phone = phone; this.enabled = enabled; }
    }
}
