package com.seanmckenna.stockroom;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.EditText;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import com.google.android.material.button.MaterialButton;

/** Shared login and registration screen with database-backed authentication. */
public class LoginFragment extends Fragment {
    private boolean registering;
    public LoginFragment() { super(R.layout.fragment_login); }

    @Override public void onViewCreated(@NonNull View view, Bundle state) {
        super.onViewCreated(view, state);
        registering = state != null && state.getBoolean("registering");
        renderMode(view);
        view.findViewById(R.id.logInButton).setOnClickListener(v -> {
            submit();
        });
        view.findViewById(R.id.createAccountButton).setOnClickListener(v -> {
            registering = !registering;
            renderMode(view);
            if (registering) view.findViewById(R.id.confirmPassword).requestFocus();
        });
    }

    private void submit() {
        View view = requireView();
        String username = ((EditText) view.findViewById(R.id.username)).getText().toString().trim();
        char[] password = ((EditText) view.findViewById(R.id.password)).getText().toString().toCharArray();
        String confirm = ((EditText) view.findViewById(R.id.confirmPassword)).getText().toString();
        TextView error = view.findViewById(R.id.loginError);
        error.setText("");
        if (username.isEmpty() || password.length == 0 || password.length > 128) {
            error.setText("Enter your username and a password of up to 128 characters.");
            java.util.Arrays.fill(password, '\0');
            return;
        }
        if (registering && !java.util.Arrays.equals(password, confirm.toCharArray())) {
            error.setText("Passwords do not match.");
            java.util.Arrays.fill(password, '\0');
            return;
        }
        MainActivity activity = (MainActivity) requireActivity();
        boolean create = registering;
        setBusy(true);
        activity.task(this, () -> {
            try {
                return create ? activity.app().database.register(username, password)
                        : activity.app().database.authenticate(username, password);
            } finally { java.util.Arrays.fill(password, '\0'); }
        }, id -> {
            setBusy(false);
            if (id < 0) error.setText("Username or password is incorrect.");
            else activity.signedIn(id);
        });
    }

    void setBusy(boolean busy) {
        if (getView() == null) return;
        getView().findViewById(R.id.logInButton).setEnabled(!busy);
        ((TextView) getView().findViewById(R.id.logInButton)).setText(busy ? R.string.please_wait
                : registering ? R.string.createAccountButton : R.string.logInButton);
        getView().findViewById(R.id.createAccountButton).setEnabled(!busy);
    }

    private void renderMode(View view) {
        ((TextView)view.findViewById(R.id.loginTitle)).setText(
                registering ? R.string.register_title : R.string.welcome);
        ((TextView)view.findViewById(R.id.loginDescription)).setText(
                registering ? R.string.register_desc : R.string.login_desc);
        view.findViewById(R.id.confirmPasswordLayout).setVisibility(registering ? View.VISIBLE : View.GONE);
        ((MaterialButton)view.findViewById(R.id.logInButton)).setText(
                registering ? R.string.createAccountButton : R.string.logInButton);
        ((MaterialButton)view.findViewById(R.id.createAccountButton)).setText(
                registering ? R.string.back_to_login : R.string.createAccountButton);
        view.findViewById(R.id.password).setNextFocusForwardId(
                registering ? R.id.confirmPassword : R.id.logInButton);
    }

    @Override public void onSaveInstanceState(@NonNull Bundle out) {
        super.onSaveInstanceState(out);
        out.putBoolean("registering", registering);
    }

    @Override public void onDestroyView() {
        // Clear sensitive fields before the view is released; XML also disables state saving.
        if (getView() != null) {
            ((EditText)getView().findViewById(R.id.password)).setText("");
            ((EditText)getView().findViewById(R.id.confirmPassword)).setText("");
        }
        super.onDestroyView();
    }
}
