package com.seanmckenna.stockroom;

import android.Manifest;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.TextView;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.switchmaterial.SwitchMaterial;
import com.google.android.material.snackbar.Snackbar;

/** Contextual SMS permission request plus explicit, per-account alert preferences. */
public class NotificationSettingsFragment extends Fragment {
    private boolean updating;
    private final ActivityResultLauncher<String> permissionRequest = registerForActivityResult(
            new ActivityResultContracts.RequestPermission(), granted -> {
                preferences().edit().putBoolean("requested", true).apply();
                if (!granted) disableStoredAlerts();
                if (getView() != null) refreshPermissionState();
            });

    public NotificationSettingsFragment() { super(R.layout.fragment_notification_settings); }
    private SharedPreferences preferences() {
        return requireContext().getSharedPreferences("sms_ui_preferences",Context.MODE_PRIVATE);
    }
    boolean hasSmsPermission() {
        return ContextCompat.checkSelfPermission(requireContext(),Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED;
    }
    boolean hasTelephony() {
        return SmsNotifier.supported(requireContext());
    }
    @Override public void onViewCreated(@NonNull View v,Bundle state) {
        super.onViewCreated(v,state);
        ((MaterialToolbar)v.findViewById(R.id.toolbar)).setNavigationOnClickListener(clicked -> leave());
        v.findViewById(R.id.continueButton).setOnClickListener(clicked -> leave());
        v.findViewById(R.id.enableSmsButton).setOnClickListener(clicked -> requestAccess());
        ((SwitchMaterial)v.findViewById(R.id.smsOptIn)).setOnCheckedChangeListener((button,checked) -> {
            if (updating) return;
            boolean permitted = hasTelephony() && hasSmsPermission();
            if (checked && !permitted) ((SwitchMaterial) button).setChecked(false);
        });
        v.findViewById(R.id.saveSmsButton).setOnClickListener(clicked -> saveSettings());
        loadSettings(state != null);
        refreshPermissionState();
    }
    private void loadSettings(boolean preserveDraft) {
        MainActivity activity = (MainActivity) requireActivity();
        long user = activity.userId();
        activity.task(this, () -> activity.app().database.settings(user), settings -> {
            if (!preserveDraft) {
                ((android.widget.EditText) requireView().findViewById(R.id.phoneInput)).setText(settings.phone);
                updating = true;
                ((SwitchMaterial) requireView().findViewById(R.id.smsOptIn)).setChecked(
                        settings.enabled && hasTelephony() && hasSmsPermission());
                updating = false;
            }
        });
    }
    private void disableStoredAlerts() {
        if (!isAdded()) return;
        MainActivity activity = (MainActivity) requireActivity();
        long user = activity.userId();
        activity.app().worker.execute(() -> activity.app().database.disableSms(user));
    }
    private void saveSettings() {
        View v = requireView();
        String phone = ((android.widget.EditText) v.findViewById(R.id.phoneInput)).getText().toString()
                .replaceAll("[\\s()-]", "");
        boolean enabled = ((SwitchMaterial) v.findViewById(R.id.smsOptIn)).isChecked()
                && hasTelephony() && hasSmsPermission();
        MainActivity activity = (MainActivity) requireActivity();
        long user = activity.userId();
        activity.task(this, () -> {
            activity.app().database.saveSettings(user, phone, enabled);
            return true;
        }, saved -> Snackbar.make(v, R.string.settings_saved, Snackbar.LENGTH_LONG).show());
    }
    @Override public void onResume() {
        super.onResume();
        if (getView() != null) {
            refreshPermissionState();
            if (!hasSmsPermission()) disableStoredAlerts();
            MainActivity activity = (MainActivity) requireActivity();
            long user = activity.userId();
            activity.task(this, () -> activity.app().database.lastAlert(user), text ->
                    ((TextView) requireView().findViewById(R.id.lastSmsResult)).setText(text));
        }
    }
    private void leave() { ((MainActivity)requireActivity()).backToInventory(); }

    private void requestAccess() {
        if (!hasTelephony() || hasSmsPermission()) { refreshPermissionState(); return; }
        if (shouldShowRequestPermissionRationale(Manifest.permission.SEND_SMS)) {
            new MaterialAlertDialogBuilder(requireContext()).setTitle(R.string.sms_rationale_title)
                    .setMessage(R.string.sms_rationale).setNegativeButton(R.string.sms_not_now,null)
                    .setPositiveButton(R.string.sms_request_again,(dialog,which) -> launchRequest()).show();
        } else if (preferences().getBoolean("requested",false)) {
            try {
                startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                        Uri.parse("package:"+requireContext().getPackageName())));
            } catch (ActivityNotFoundException e) {
                Snackbar.make(requireView(),R.string.sms_settings_missing,Snackbar.LENGTH_LONG).show();
            }
        } else launchRequest();
    }

    private void launchRequest() {
        // Recheck immediately before requesting. Never trigger a prompt on screen entry.
        if (hasTelephony() && !hasSmsPermission()) permissionRequest.launch(Manifest.permission.SEND_SMS);
        else refreshPermissionState();
    }

    void refreshPermissionState() {
        View v = requireView();
        boolean supported = hasTelephony(), granted = hasSmsPermission();
        boolean requested = preferences().getBoolean("requested",false);
        boolean settings = requested && !shouldShowRequestPermissionRationale(Manifest.permission.SEND_SMS);
        int title,detail,action;
        if (!supported) {
            title=R.string.sms_unavailable; detail=R.string.sms_unavailable_detail; action=R.string.sms_unavailable_button;
        } else if (granted) {
            title=R.string.sms_granted; detail=R.string.sms_granted_detail; action=R.string.sms_allowed_button;
        } else if (requested) {
            title=R.string.sms_denied; detail=R.string.sms_denied_detail;
            action=settings ? R.string.sms_settings : R.string.sms_enable;
        } else {
            title=R.string.sms_status_pending; detail=R.string.sms_pending_detail; action=R.string.sms_enable;
        }
        ((TextView)v.findViewById(R.id.smsStatus)).setText(title);
        ((TextView)v.findViewById(R.id.smsStatusDetail)).setText(detail);
        MaterialButton button=v.findViewById(R.id.enableSmsButton);
        button.setText(action); button.setEnabled(supported && !granted);
        updating=true;
        SwitchMaterial toggle=v.findViewById(R.id.smsOptIn);
        toggle.setEnabled(supported && granted);
        if (!supported || !granted) toggle.setChecked(false);
        updating=false;
        v.findViewById(R.id.phoneInput).setEnabled(supported);
    }
}
