package com.seanmckenna.stockroom;

/** Immutable snapshot of one account-owned SQLite record. */
final class InventoryItem {
    final long id;
    final String name, sku, location;
    final int quantity;
    InventoryItem(long id, String name, String sku, String location, int quantity) {
        this.id = id;
        this.name = name;
        this.sku = sku;
        this.location = location;
        this.quantity = quantity;
    }
}
