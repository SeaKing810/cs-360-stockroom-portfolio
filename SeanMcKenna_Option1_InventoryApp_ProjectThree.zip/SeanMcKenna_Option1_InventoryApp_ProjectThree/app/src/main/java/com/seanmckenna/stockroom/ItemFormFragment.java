package com.seanmckenna.stockroom;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.snackbar.Snackbar;

/** Validates item details and saves only after an explicit user action. */
public class ItemFormFragment extends Fragment {
    private String originalName = "", originalSku = "", originalLocation = "", originalQuantity = "";
    private long itemId = -1;
    private boolean busy;
    public ItemFormFragment() { super(R.layout.fragment_item_form); }
    static ItemFormFragment forItem(long id) {
        ItemFormFragment fragment = new ItemFormFragment();
        Bundle args = new Bundle(); args.putLong("itemId", id); fragment.setArguments(args);
        return fragment;
    }
    @Override public void onViewCreated(@NonNull View v, Bundle state) {
        super.onViewCreated(v, state);
        itemId = requireArguments().getLong("itemId", -1);
        if (state != null) {
            originalName = state.getString("originalName", "");
            originalSku = state.getString("originalSku", "");
            originalLocation = state.getString("originalLocation", "");
            originalQuantity = state.getString("originalQuantity", "");
        }
        MainActivity activity = (MainActivity) requireActivity();
        if (itemId >= 0) {
            ((TextView) v.findViewById(R.id.formTitle)).setText(R.string.edit_item);
            setBusy(true);
            long user = activity.userId();
            activity.task(this, () -> activity.app().database.item(user, itemId), item -> {
                originalName = item.name; originalSku = item.sku;
                originalLocation = item.location; originalQuantity = String.valueOf(item.quantity);
                if (state == null) fillForm();
                setBusy(false);
                v.findViewById(R.id.deleteItemButton).setVisibility(View.VISIBLE);
                v.findViewById(R.id.deleteItemButton).setOnClickListener(clicked ->
                        InventoryFragment.confirmDelete(this, item, activity::backToInventory));
            });
        } else if (state == null) fillForm();
        ((MaterialToolbar) v.findViewById(R.id.toolbar)).setNavigationOnClickListener(clicked -> leaveForm());
        v.findViewById(R.id.cancelButton).setOnClickListener(clicked -> leaveForm());
        v.findViewById(R.id.saveItemButton).setOnClickListener(clicked -> save());
        requireActivity().getOnBackPressedDispatcher().addCallback(getViewLifecycleOwner(), new OnBackPressedCallback(true) {
            @Override public void handleOnBackPressed() { leaveForm(); }
        });
    }
    private void fillForm() {
        ((EditText) requireView().findViewById(R.id.itemNameInput)).setText(originalName);
        ((EditText) requireView().findViewById(R.id.skuInput)).setText(originalSku);
        ((EditText) requireView().findViewById(R.id.locationInput)).setText(originalLocation);
        ((EditText) requireView().findViewById(R.id.quantityInput)).setText(originalQuantity);
    }
    private void save() {
        String name = value(R.id.itemNameInput), sku = value(R.id.skuInput), location = value(R.id.locationInput);
        int quantity;
        try {
            quantity = Integer.parseInt(value(R.id.quantityInput).trim());
            StockroomDatabase.validateItem(name, sku, location, quantity);
        } catch (IllegalArgumentException error) {
            String message = error instanceof NumberFormatException
                    ? "Enter a whole-number quantity from 0 to 1,000,000." : error.getMessage();
            Snackbar.make(requireView(), message, Snackbar.LENGTH_LONG).show();
            return;
        }
        MainActivity activity = (MainActivity) requireActivity();
        long user = activity.userId();
        setBusy(true);
        activity.task(this, () -> {
            long event = activity.app().database.saveItem(user, itemId, name, sku, location, quantity);
            SmsNotifier.send(activity.getApplicationContext(), activity.app().database, user, event);
            return event;
        }, event -> {
            setBusy(false);
            activity.backToInventory();
        });
    }
    void setBusy(boolean value) {
        busy = value;
        if (getView() != null) {
            getView().findViewById(R.id.saveItemButton).setEnabled(!value);
            getView().findViewById(R.id.deleteItemButton).setEnabled(!value);
        }
    }
    private String value(int id) { return ((EditText) requireView().findViewById(id)).getText().toString(); }
    private void leaveForm() {
        if (busy) return;
        boolean changed = !originalName.equals(value(R.id.itemNameInput)) || !originalSku.equals(value(R.id.skuInput))
                || !originalLocation.equals(value(R.id.locationInput)) || !originalQuantity.equals(value(R.id.quantityInput));
        if (changed) new MaterialAlertDialogBuilder(requireContext()).setTitle(R.string.discard_title)
                .setMessage(R.string.discard_message).setNegativeButton(R.string.keep_editing, null)
                .setPositiveButton(R.string.discard, (dialog, which) -> ((MainActivity) requireActivity()).backToInventory()).show();
        else ((MainActivity) requireActivity()).backToInventory();
    }
    @Override public void onSaveInstanceState(@NonNull Bundle out) {
        super.onSaveInstanceState(out);
        out.putString("originalName", originalName); out.putString("originalSku", originalSku);
        out.putString("originalLocation", originalLocation); out.putString("originalQuantity", originalQuantity);
    }
}
