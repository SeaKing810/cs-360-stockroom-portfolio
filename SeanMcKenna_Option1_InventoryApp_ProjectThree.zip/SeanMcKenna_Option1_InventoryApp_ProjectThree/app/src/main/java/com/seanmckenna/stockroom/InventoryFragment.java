package com.seanmckenna.stockroom;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.chip.ChipGroup;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.textfield.TextInputEditText;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class InventoryFragment extends Fragment {
    private String query = "";
    private boolean zeroOnly;
    private List<InventoryItem> items = new ArrayList<>();
    private ItemAdapter adapter;
    public InventoryFragment() { super(R.layout.fragment_inventory); }

    @Override public void onViewCreated(@NonNull View view, Bundle state) {
        super.onViewCreated(view, state);
        if (state != null) {
            query = state.getString("query", "");
            zeroOnly = state.getBoolean("zeroOnly");
        }
        MainActivity activity = (MainActivity) requireActivity();
        MaterialToolbar toolbar = view.findViewById(R.id.toolbar);
        toolbar.setOnMenuItemClickListener(item -> {
            if (item.getItemId() == R.id.menuAlerts) activity.showScreen(new NotificationSettingsFragment());
            else if (item.getItemId() == R.id.menuLogout) activity.logout();
            return true;
        });
        RecyclerView grid = view.findViewById(R.id.inventoryGrid);
        int initialColumns = getResources().getConfiguration().screenWidthDp >= 648
                && getResources().getConfiguration().fontScale <= 1.3f ? 2 : 1;
        GridLayoutManager manager = new GridLayoutManager(requireContext(), initialColumns);
        grid.setLayoutManager(manager);
        adapter = new ItemAdapter();
        grid.setAdapter(adapter);
        // Two columns only when each card has room, including enlarged text.
        grid.addOnLayoutChangeListener((v,l,t,r,b,ol,ot,or,ob) -> {
            float density = getResources().getDisplayMetrics().density;
            float scale = getResources().getConfiguration().fontScale;
            int columns = (r-l)/density >= 600 && scale <= 1.3f ? 2 : 1;
            if (manager.getSpanCount() != columns) manager.setSpanCount(columns);
        });
        TextInputEditText search = view.findViewById(R.id.search);
        ChipGroup filters = view.findViewById(R.id.filterGroup);
        search.setText(query);
        filters.check(zeroOnly ? R.id.zeroFilter : R.id.allFilter);
        search.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s,int start,int count,int after) {}
            public void onTextChanged(CharSequence s,int start,int before,int count) {
                query = s.toString(); adapter.filter(view);
            }
            public void afterTextChanged(Editable s) {}
        });
        filters.setOnCheckedStateChangeListener((group, ids) -> {
            zeroOnly = ids.contains(R.id.zeroFilter); adapter.filter(view);
        });
        view.findViewById(R.id.addItemButton).setOnClickListener(v -> activity.showScreen(ItemFormFragment.forItem(-1)));
        reload();
    }

    @Override public void onSaveInstanceState(@NonNull Bundle out) {
        super.onSaveInstanceState(out);
        out.putString("query", query); out.putBoolean("zeroOnly", zeroOnly);
    }

    private void reload() {
        MainActivity activity = (MainActivity) requireActivity();
        long user = activity.userId();
        activity.task(this, () -> activity.app().database.items(user), result -> {
            items = result;
            long zeroCount = items.stream().filter(item -> item.quantity == 0).count();
            ((TextView) requireView().findViewById(R.id.stockSummary)).setText(
                    getString(R.string.stock_summary, items.size(), zeroCount));
            adapter.filter(requireView());
        });
    }

    private void changeQuantity(InventoryItem item, int delta) {
        MainActivity activity = (MainActivity) requireActivity();
        long user = activity.userId();
        activity.task(this, () -> {
            long event = activity.app().database.adjustQuantity(user, item.id, delta);
            SmsNotifier.send(activity.getApplicationContext(), activity.app().database, user, event);
            return event;
        }, event -> {
            reload();
            if (event >= 0) Snackbar.make(requireView(), R.string.zero_saved, Snackbar.LENGTH_LONG).show();
        });
    }

    static void confirmDelete(Fragment fragment, InventoryItem item, Runnable done) {
        MainActivity activity = (MainActivity) fragment.requireActivity();
        long user = activity.userId();
        new MaterialAlertDialogBuilder(fragment.requireContext())
                .setTitle(fragment.getString(R.string.delete_title, item.name))
                .setMessage(R.string.delete_message)
                .setNegativeButton(R.string.cancel, null)
                .setPositiveButton(R.string.delete, (dialog, which) -> activity.task(fragment, () -> {
                    activity.app().database.deleteItem(user, item.id);
                    return true;
                }, result -> done.run())).show();
    }

    private final class ItemAdapter extends RecyclerView.Adapter<ItemHolder> {
        private final List<InventoryItem> visible = new ArrayList<>();
        void filter(View root) {
            visible.clear();
            String term = query.trim().toLowerCase(Locale.ROOT);
            for (InventoryItem item : items) {
                if ((!zeroOnly || item.quantity == 0) && (item.name.toLowerCase(Locale.ROOT).contains(term)
                        || item.sku.toLowerCase(Locale.ROOT).contains(term))) visible.add(item);
            }
            notifyDataSetChanged();
            TextView empty = root.findViewById(R.id.noMatches);
            empty.setText(items.isEmpty() ? R.string.empty_inventory : R.string.no_match);
            empty.setVisibility(visible.isEmpty() ? View.VISIBLE : View.GONE);
        }
        @NonNull @Override public ItemHolder onCreateViewHolder(@NonNull ViewGroup parent,int type) {
            return new ItemHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.item_inventory,parent,false));
        }
        @Override public void onBindViewHolder(@NonNull ItemHolder holder,int position) {
            InventoryItem item = visible.get(position);
            View v = holder.itemView;
            ((TextView)v.findViewById(R.id.itemName)).setText(item.name);
            ((TextView)v.findViewById(R.id.itemSku)).setText(getString(R.string.sku_value,item.sku));
            ((TextView)v.findViewById(R.id.itemLocation)).setText(getString(R.string.location_value,item.location));
            TextView quantity = v.findViewById(R.id.itemQuantity);
            quantity.setText(String.valueOf(item.quantity));
            quantity.setContentDescription(getString(R.string.quantity_accessibility,item.quantity));
            TextView status = v.findViewById(R.id.itemStatus);
            status.setText(item.quantity == 0 ? R.string.out_of_stock : R.string.in_stock);
            status.setTextColor(ContextCompat.getColor(requireContext(),item.quantity == 0 ? R.color.danger : R.color.primary));
            v.findViewById(R.id.decreaseButton).setEnabled(item.quantity > 0);
            v.findViewById(R.id.increaseButton).setContentDescription(getString(R.string.increase_accessibility,item.name));
            v.findViewById(R.id.decreaseButton).setContentDescription(getString(R.string.decrease_accessibility,item.name));
            v.findViewById(R.id.editButton).setContentDescription(getString(R.string.edit_accessibility,item.name));
            v.findViewById(R.id.deleteButton).setContentDescription(getString(R.string.delete_accessibility,item.name));
            v.findViewById(R.id.increaseButton).setEnabled(item.quantity < StockroomDatabase.MAX_QUANTITY);
            v.findViewById(R.id.increaseButton).setOnClickListener(clicked -> changeQuantity(item, 1));
            v.findViewById(R.id.decreaseButton).setOnClickListener(clicked -> changeQuantity(item, -1));
            v.findViewById(R.id.editButton).setOnClickListener(clicked -> ((MainActivity)requireActivity())
                    .showScreen(ItemFormFragment.forItem(item.id)));
            v.findViewById(R.id.deleteButton).setOnClickListener(clicked -> confirmDelete(InventoryFragment.this, item, () -> reload()));
        }
        @Override public int getItemCount() { return visible.size(); }
    }
    private static final class ItemHolder extends RecyclerView.ViewHolder {
        ItemHolder(View view) { super(view); }
    }
}
