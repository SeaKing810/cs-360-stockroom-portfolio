package com.seanmckenna.stockroom;

import android.content.res.Configuration;
import android.os.Bundle;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

/** Hosts account-scoped screens and keeps database work off the main thread. */
public class MainActivity extends AppCompatActivity {
    private long userId = -1;
    long userId() { return userId; }
    StockroomApp app() { return (StockroomApp) getApplication(); }
    void signedIn(long id) { userId = id; showRoot(new InventoryFragment()); }
    void logout() { userId = -1; showRoot(new LoginFragment()); }
    @Override public void onSaveInstanceState(Bundle state) {
        state.putLong("userId", userId);
        super.onSaveInstanceState(state);
    }
    <T> void task(Fragment owner, java.util.concurrent.Callable<T> work, java.util.function.Consumer<T> success) {
        View originalView = owner.getView();
        app().worker.execute(() -> {
            try {
                T result = work.call();
                runOnUiThread(() -> {
                    if (!isFinishing() && owner.isAdded() && owner.getView() == originalView && originalView != null)
                        success.accept(result);
                });
            } catch (Exception error) {
                runOnUiThread(() -> {
                    if (owner.isAdded() && owner.getView() == originalView && originalView != null) {
                        String message = error instanceof IllegalArgumentException ? error.getMessage()
                                : "Could not save or load data. Please try again.";
                        com.google.android.material.snackbar.Snackbar.make(originalView, message,
                                com.google.android.material.snackbar.Snackbar.LENGTH_LONG).show();
                        // Never log passwords, phone numbers, or inventory values.
                        if (owner instanceof LoginFragment) ((LoginFragment) owner).setBusy(false);
                        if (owner instanceof ItemFormFragment) ((ItemFormFragment) owner).setBusy(false);
                    }
                });
            }
        });
    }

    @Override public void onCreate(Bundle state) {
        userId = state == null ? -1 : state.getLong("userId", -1);
        super.onCreate(state);
        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
        setContentView(R.layout.activity_main);
        boolean light = (getResources().getConfiguration().uiMode
                & Configuration.UI_MODE_NIGHT_MASK) != Configuration.UI_MODE_NIGHT_YES;
        WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView())
                .setAppearanceLightStatusBars(light);
        WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView())
                .setAppearanceLightNavigationBars(light);
        View host = findViewById(R.id.screenHost);
        ViewCompat.setOnApplyWindowInsetsListener(host, (view, windowInsets) -> {
            Insets safe = windowInsets.getInsets(WindowInsetsCompat.Type.systemBars()
                    | WindowInsetsCompat.Type.displayCutout() | WindowInsetsCompat.Type.ime());
            view.setPadding(safe.left, safe.top, safe.right, safe.bottom);
            return windowInsets;
        });
        ViewCompat.requestApplyInsets(host);
        if (state == null) showRoot(new LoginFragment());
    }

    void showRoot(Fragment screen) {
        getSupportFragmentManager().popBackStackImmediate(null, FragmentManager.POP_BACK_STACK_INCLUSIVE);
        getSupportFragmentManager().beginTransaction()
                .setCustomAnimations(android.R.anim.fade_in, android.R.anim.fade_out)
                .replace(R.id.screenHost, screen).commit();
    }

    void showScreen(Fragment screen) {
        getSupportFragmentManager().beginTransaction()
                .setCustomAnimations(android.R.anim.fade_in, android.R.anim.fade_out,
                        android.R.anim.fade_in, android.R.anim.fade_out)
                .replace(R.id.screenHost, screen).addToBackStack(null).commit();
    }

    void backToInventory() { getSupportFragmentManager().popBackStack(); }
}
