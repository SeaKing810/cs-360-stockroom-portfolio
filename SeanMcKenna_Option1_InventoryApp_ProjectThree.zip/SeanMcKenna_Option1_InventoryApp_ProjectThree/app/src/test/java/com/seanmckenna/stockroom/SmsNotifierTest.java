package com.seanmckenna.stockroom;

import static org.junit.Assert.*;
import static org.robolectric.Shadows.shadowOf;
import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.telephony.SmsManager;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.RuntimeEnvironment;
import org.robolectric.annotation.Config;
import org.robolectric.shadows.ShadowSmsManager;
import org.robolectric.shadows.ShadowSubscriptionManager;

@RunWith(RobolectricTestRunner.class)
@Config(sdk = 34)
public class SmsNotifierTest {
    Context context;
    StockroomDatabase db;
    long user, event;
    ShadowSmsManager sms;
    @Before public void start() {
        context = RuntimeEnvironment.getApplication();
        db = ((StockroomApp) context).database;
        user = db.register("tester","StrongPass1".toCharArray());
        db.saveSettings(user,"+15551234567",true);
        db.saveItem(user,-1,"Tape","T-01","",1);
        event = db.adjustQuantity(user,db.items(user).get(0).id,-1);
        shadowOf(context.getPackageManager()).setSystemFeature(PackageManager.FEATURE_TELEPHONY_MESSAGING,true);
        shadowOf(RuntimeEnvironment.getApplication()).grantPermissions(Manifest.permission.SEND_SMS);
        ShadowSubscriptionManager.setDefaultSmsSubscriptionId(1);
        sms = shadowOf(context.getSystemService(SmsManager.class).createForSubscriptionId(1));
    }
    @Test public void grantedAndOptedInSendsExpectedAlert() {
        SmsNotifier.send(context,db,user,event);
        assertNotNull(sms.getLastSentTextMessageParams());
        assertEquals("+15551234567",sms.getLastSentTextMessageParams().getDestinationAddress());
        assertEquals("Stockroom: T-01 is out of stock. Quantity: 0.",sms.getLastSentTextMessageParams().getText());
        assertTrue(db.lastAlert(user).contains("Submitted"));
    }
    @Test public void permissionDenialSkipsSmsAndKeepsInventoryFunctional() {
        shadowOf(RuntimeEnvironment.getApplication()).denyPermissions(Manifest.permission.SEND_SMS);
        SmsNotifier.send(context,db,user,event);
        assertNull(sms.getLastSentTextMessageParams());
        db.saveItem(user,-1,"Another","B","",4);
        assertEquals(2,db.items(user).size());
    }
    @Test public void disabledPreferenceDoesNotSend() {
        db.disableSms(user); SmsNotifier.send(context,db,user,event);
        assertNull(sms.getLastSentTextMessageParams());
    }
    @Test public void missingTelephonyDoesNotSend() {
        shadowOf(context.getPackageManager()).setSystemFeature(PackageManager.FEATURE_TELEPHONY_MESSAGING,false);
        SmsNotifier.send(context,db,user,event); assertNull(sms.getLastSentTextMessageParams());
    }
    @Test public void missingDefaultSimRecordsFailureWithoutLosingQuantity() {
        ShadowSubscriptionManager.setDefaultSmsSubscriptionId(-1);
        SmsNotifier.send(context,db,user,event);
        assertNull(sms.getLastSentTextMessageParams()); assertTrue(db.lastAlert(user).contains("default SMS SIM"));
        assertEquals(0,db.items(user).get(0).quantity);
    }
    @Test public void noTransitionNeverSends() {
        SmsNotifier.send(context,db,user,-1); assertNull(sms.getLastSentTextMessageParams());
    }
}
