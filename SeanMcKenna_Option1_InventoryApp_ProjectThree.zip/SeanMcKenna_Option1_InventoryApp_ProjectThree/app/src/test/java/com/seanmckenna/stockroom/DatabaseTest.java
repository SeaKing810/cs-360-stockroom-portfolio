package com.seanmckenna.stockroom;

import static org.junit.Assert.*;
import android.database.Cursor;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.RuntimeEnvironment;
import org.robolectric.annotation.Config;

@RunWith(RobolectricTestRunner.class)
@Config(sdk = 34)
public class DatabaseTest {
    StockroomDatabase db;
    long user;
    @Before public void start() {
        db = ((StockroomApp) RuntimeEnvironment.getApplication()).database;
        user = db.register("tester", "StrongPass1".toCharArray());
    }
    @After public void stop() { db.close(); }
    @Test public void newAccountStartsWithEmptyInventory() { assertTrue(db.items(user).isEmpty()); }
    @Test public void credentialsAreCheckedAndUsernameIsCaseInsensitive() {
        assertEquals(user, db.authenticate("TESTER", "StrongPass1".toCharArray()));
        assertEquals(-1, db.authenticate("tester", "wrong".toCharArray()));
        assertEquals(-1, db.authenticate("missing", "StrongPass1".toCharArray()));
        assertEquals(-1, db.authenticate("' OR 1=1 --", "StrongPass1".toCharArray()));
    }
    @Test public void duplicateAndInvalidCredentialsAreRejected() {
        assertThrows(IllegalArgumentException.class, () -> db.register("TESTER", "StrongPass1".toCharArray()));
        assertThrows(IllegalArgumentException.class, () -> db.register("a", "StrongPass1".toCharArray()));
        assertThrows(IllegalArgumentException.class, () -> db.register("another", "short".toCharArray()));
    }
    @Test public void passwordsUseDifferentSaltsAndAreNotPlaintext() {
        db.register("second", "StrongPass1".toCharArray());
        try (Cursor c = db.getReadableDatabase().rawQuery("SELECT salt,password_hash FROM users ORDER BY _id", null)) {
            assertTrue(c.moveToFirst()); byte[] firstSalt = c.getBlob(0), firstHash = c.getBlob(1);
            assertEquals(16, firstSalt.length); assertEquals(32, firstHash.length);
            assertTrue(c.moveToNext()); assertFalse(java.util.Arrays.equals(firstSalt,c.getBlob(0)));
            assertFalse(java.util.Arrays.equals(firstHash,c.getBlob(1)));
        }
    }
    @Test public void createReadUpdateDeleteAndReopenPersist() {
        db.saveItem(user, -1, "Tape", "t-01", "A1", 3);
        long id = db.items(user).get(0).id;
        db.saveItem(user, id, "Packing tape", "T-02", "B2", 5);
        db.close(); db = new StockroomDatabase(RuntimeEnvironment.getApplication());
        assertEquals(user, db.authenticate("tester", "StrongPass1".toCharArray()));
        InventoryItem item = db.item(user, id);
        assertEquals("Packing tape", item.name); assertEquals("T-02", item.sku);
        assertEquals("B2", item.location); assertEquals(5, item.quantity);
        db.deleteItem(user, id); assertTrue(db.items(user).isEmpty());
    }
    @Test public void allOperationsAreScopedToAccount() {
        long second = db.register("second", "StrongPass1".toCharArray());
        db.saveItem(user, -1, "Private", "A", "", 1);
        long id = db.items(user).get(0).id;
        assertTrue(db.items(second).isEmpty());
        assertThrows(IllegalArgumentException.class, () -> db.item(second,id));
        assertThrows(IllegalArgumentException.class, () -> db.deleteItem(second,id));
        assertThrows(IllegalArgumentException.class, () -> db.saveItem(second,id,"Changed","A","",2));
        db.saveItem(second,-1,"Other","A","",2); // Same SKU in another account is allowed.
        assertEquals(1, db.item(user,id).quantity);
    }
    @Test public void duplicateSkuAndInvalidQuantitiesAreRejected() {
        db.saveItem(user,-1,"Tape","PKG-1","",1);
        assertThrows(IllegalArgumentException.class, () -> db.saveItem(user,-1,"Other","pkg-1","",2));
        assertThrows(IllegalArgumentException.class, () -> db.saveItem(user,-1,"Other","B","",-1));
        assertThrows(IllegalArgumentException.class, () -> db.saveItem(user,-1,"Other","B","",1_000_001));
        assertThrows(IllegalArgumentException.class, () -> db.saveItem(user,-1," ","B","",1));
        assertEquals(1, db.items(user).size());
    }
    @Test public void onlyPositiveToZeroTransitionsProduceEvents() {
        assertEquals(-1, db.saveItem(user,-1,"Tape","A","",0));
        long id=db.items(user).get(0).id;
        assertEquals(-1, db.saveItem(user,id,"Tape","A","",0));
        assertEquals(-1, db.adjustQuantity(user,id,1));
        assertTrue(db.adjustQuantity(user,id,-1) > 0);
        assertEquals(-1, db.saveItem(user,id,"Tape","A","",0));
        assertThrows(IllegalArgumentException.class, () -> db.adjustQuantity(user,id,-1));
        assertEquals(0, db.item(user,id).quantity);
    }
    @Test public void settingsPersistAndValidatePhone() {
        db.saveSettings(user,"+15551234567",true);
        db.close(); db = new StockroomDatabase(RuntimeEnvironment.getApplication());
        assertTrue(db.settings(user).enabled); assertEquals("+15551234567",db.settings(user).phone);
        assertThrows(IllegalArgumentException.class, () -> db.saveSettings(user,"555",true));
        db.disableSms(user); assertFalse(db.settings(user).enabled);
    }
}
