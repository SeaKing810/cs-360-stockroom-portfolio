package com.seanmckenna.stockroom;

import static org.junit.Assert.*;
import static org.robolectric.Shadows.shadowOf;
import android.Manifest;
import android.os.Looper;
import android.content.pm.PackageManager;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.Robolectric;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.RuntimeEnvironment;
import org.robolectric.android.controller.ActivityController;
import org.robolectric.annotation.Config;

@RunWith(RobolectricTestRunner.class)
@Config(sdk=34, qualifiers="w411dp-h891dp-xhdpi")
public class ScreenFlowTest {
    ActivityController<MainActivity> controller;
    MainActivity activity;
    long user;
    @Before public void start() throws Exception {
        controller=Robolectric.buildActivity(MainActivity.class).setup();
        activity=controller.get();
        user=activity.app().database.register("tester","StrongPass1".toCharArray());
        settle();
    }
    @After public void stop() { controller.pause().stop().destroy(); }
    void settle() throws Exception {
        for (int i=0;i<3;i++) {
            activity.getSupportFragmentManager().executePendingTransactions();
            activity.app().worker.submit(() -> {}).get(30,java.util.concurrent.TimeUnit.SECONDS);
            shadowOf(Looper.getMainLooper()).idle();
        }
    }
    void text(int id,String text) { ((EditText)activity.findViewById(id)).setText(text); }
    void click(int id) throws Exception { activity.findViewById(id).performClick(); settle(); }
    @Test public void badLoginStaysOnLoginAndValidLoginOpensEmptyGrid() throws Exception {
        text(R.id.username,"tester"); text(R.id.password,"wrong"); click(R.id.logInButton);
        assertTrue(((TextView)activity.findViewById(R.id.loginError)).getText().toString().contains("incorrect"));
        text(R.id.password,"StrongPass1"); click(R.id.logInButton);
        assertEquals(user,activity.userId());
        assertEquals(0,((RecyclerView)activity.findViewById(R.id.inventoryGrid)).getAdapter().getItemCount());
        assertTrue(((TextView)activity.findViewById(R.id.noMatches)).getText().toString().contains("empty"));
    }
    @Test public void formActuallySavesAndSearchFiltersDatabaseRecords() throws Exception {
        activity.signedIn(user);settle();click(R.id.addItemButton);
        text(R.id.itemNameInput,"Tape");text(R.id.skuInput,"T-1");text(R.id.quantityInput,"8");click(R.id.saveItemButton);
        assertEquals(8,activity.app().database.items(user).get(0).quantity);
        RecyclerView grid=activity.findViewById(R.id.inventoryGrid);assertEquals(1,grid.getAdapter().getItemCount());
        text(R.id.search,"missing");settle();assertEquals(0,grid.getAdapter().getItemCount());
        text(R.id.search,"Tape");settle();assertEquals(1,grid.getAdapter().getItemCount());
    }
    @Test public void rotationKeepsAuthenticatedAccountAndLogoutClearsIt() throws Exception {
        activity.signedIn(user);settle();controller.recreate();activity=controller.get();settle();
        assertEquals(user,activity.userId());assertNotNull(activity.findViewById(R.id.inventoryGrid));
        activity.logout();settle();assertEquals(-1,activity.userId());assertNotNull(activity.findViewById(R.id.username));
    }
    @Test public void deniedSmsScreenLeavesInventoryNavigationAvailable() throws Exception {
        shadowOf(RuntimeEnvironment.getApplication().getPackageManager())
                .setSystemFeature(PackageManager.FEATURE_TELEPHONY_MESSAGING,true);
        shadowOf(RuntimeEnvironment.getApplication()).denyPermissions(Manifest.permission.SEND_SMS);
        activity.signedIn(user);settle();activity.showScreen(new NotificationSettingsFragment());settle();
        assertFalse(activity.findViewById(R.id.smsOptIn).isEnabled());
        click(R.id.continueButton);assertNotNull(activity.findViewById(R.id.inventoryGrid));
        click(R.id.addItemButton);assertNotNull(activity.findViewById(R.id.saveItemButton));
    }
    @Test @Config(qualifiers="w800dp-h1200dp-xhdpi")
    public void tabletUsesTwoColumnGrid() throws Exception {
        activity.signedIn(user);settle();
        RecyclerView grid=activity.findViewById(R.id.inventoryGrid);
        assertEquals(2,((GridLayoutManager)grid.getLayoutManager()).getSpanCount());
    }
}
